var namespaces_dup =
[
    [ "ESC", "d2/d52/namespace_e_s_c.html", "d2/d52/namespace_e_s_c" ]
];
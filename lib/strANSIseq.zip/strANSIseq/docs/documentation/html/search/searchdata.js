var indexSectionsWithContent =
{
  0: "bcdefghilmrsu",
  1: "c",
  2: "e",
  3: "mrs",
  4: "cfglm",
  5: "s",
  6: "f",
  7: "bdfhirsu",
  8: "l",
  9: "s"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Pages"
};

